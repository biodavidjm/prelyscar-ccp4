Run the script with the following arguments:

./prelyscarATccp4.pl PDB.pdb CHAIN PRIOR_PROBABILITY

Examples:
./prelyscarATccp4.pl 3U4F.pdb A 0.009
./prelyscarATccp4.pl 5COX.pdb A 0.009


